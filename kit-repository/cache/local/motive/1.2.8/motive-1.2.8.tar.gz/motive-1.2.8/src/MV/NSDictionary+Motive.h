#import <Foundation/Foundation.h>
#import "MVMacros.h"

@interface NSDictionary (MotiveExtensions)

READ BOOL isEmpty;
READ BOOL isNotEmpty;

@end
