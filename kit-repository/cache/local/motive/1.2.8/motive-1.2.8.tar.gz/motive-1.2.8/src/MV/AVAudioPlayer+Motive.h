#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>

@interface AVAudioPlayer (AVAudioPlayerMotive)

+ (AVAudioPlayer *)audioPlayerForResource:(NSString *)resource;

@end
