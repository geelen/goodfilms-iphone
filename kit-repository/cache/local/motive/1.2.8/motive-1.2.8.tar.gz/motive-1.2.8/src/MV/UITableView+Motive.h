#import <Foundation/Foundation.h>


@interface UITableView (Motive)

- (void)reloadDataOnMainThread;

@end
