#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MVAdMobHelper : NSObject

+ (NSString *)adMobAppOpenReportedFilePath;
+ (void)reportAppStartToAdMobWithSiteId:(NSString *)siteId;
+ (void)reportAppStartToAdMobWithAppId:(NSString *)appId;

@end
