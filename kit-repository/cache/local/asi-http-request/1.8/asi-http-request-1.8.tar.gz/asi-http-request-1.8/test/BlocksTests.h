//
//  BlocksTests.h
//  Mac
//
//  Created by Ben Copsey on 18/10/2010.
//  Copyright 2010 All-Seeing Interactive. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASITestCase.h"

@interface BlocksTests : ASITestCase {

}

@end
