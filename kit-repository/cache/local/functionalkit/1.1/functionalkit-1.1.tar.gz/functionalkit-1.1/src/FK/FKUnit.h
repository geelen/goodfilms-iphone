#import <Foundation/Foundation.h>

// The unit type which has only one value.
@interface FKUnit : NSObject

+ (FKUnit *)unit;

@end
