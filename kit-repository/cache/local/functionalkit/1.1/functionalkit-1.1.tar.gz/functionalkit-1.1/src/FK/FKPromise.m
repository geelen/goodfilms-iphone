#import "FKPromise.h"

@implementation FKPromise

- (id)claim {
    return nil;
}

- (id)claim:(NSTimeInterval)timeout {
    return nil;
}


@end
